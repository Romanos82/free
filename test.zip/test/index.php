<!doctype html>
<html lang="cs">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="ares.js" type="text/javascript"></script>
    <link href="ares.css" rel="stylesheet" type="text/css" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>Data z ARES</title>
  </head>
  <body>
    <h1 style="color: blue; text-align: center">Formulář pro vyhledání firmy podle ičo</h1>
    <br>
    <br>
    
    <?php   
    
    echo "<ul><li><p>Pokud zadáte do řádku <strong>'IČO'</strong> platné hledané identifikační číslo ve správném tvaru a odešlete kliknutím na <strong>'Zjistit údaje z ARES'</strong>, do stránky Vám program vypíše údaje o firmě.</p></li>";
    echo"<p><li>Vypsané údaje lze <strong>'Vložit do formuláře'</strong> nebo kliknutím na <strong>'Zavřít'</strong> data <strong>'zahodit'</strong>. Pokud údaje vypíšete do formuláře klinutím na <strong>'Odeslat data na databázi'</strong>, uložíte vyhledané údaje.</p></li>";
    echo "<p><li>Kliknutím na <strong>'Zobrazit firmy'</strong>, program zobrazí již uložené firmy.</p></li></ul>";
    ;
    //formulář pro zadání IČO a zjištění údajů z ARES
    echo '<form action="#" method="post">  
        <table border="0">
          <tr>
            <td>IČO:</td>
            <td>
            <input class="prvek_fakturacni_ico" type="text" name="fakturacni_ico" id="fakturacni_ico" value=""/>
            </td>
          </tr>
          <tr>
            <td>Údaje z ARES:</td>
            <td>
              <span class="tl_ares">Zjistit údaje z ARES</span>
              <span id="ares_okno"></span>
              <div class="ajax_loader_ares">
                <div class="ajax_loader_ares_in">
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <td>Firma:</td>
            <td>
              <input class="prvek_fakturacni_firma" type="text" name="fakturacni_firma" value=""/>
            </td>
          </tr>
          <tr>
            <td>Adresa:</td>
            <td>
              <input class="prvek_fakturacni_adresa" type="text" name="fakturacni_adresa" value=""/>
            </td>
          </tr>
          <tr>
            <td>Město:</td>
            <td>
              <input class="prvek_fakturacni_mesto" type="text" name="fakturacni_mesto" value=""/>
            </td>
          </tr>
          <tr>
            <td>PSČ:</td>
            <td><input class="prvek_fakturacni_psc" type="text" name="fakturacni_psc" value=""/></td>
          </tr>
          <tr>
            <td>DIČ:</td>
            <td><input class="prvek_fakturacni_dic" type="text" name="fakturacni_dic" value=""/></td>
          </tr>
          <tr>
            <td>
              <label for="registrace-submit"></label>
              <input type="submit" name="registrace-submit" value="Odeslat data na databázi">
            </td>
          </tr>
        </table>
      </form>';

      //připojení na databázi
      $db = new PDO(
      "mysql:host=localhost;dbname=id17042811_data_ares;charset=utf8",
      "id17042811_roman",
      "jd%{1~]Y<W&/(9GE",
      array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION) //pokud připojení selže vypíše hlášku
      );

      $datum = date("Y-m-d");
      $cas = date("H:m:s");

      if(array_key_exists("registrace-submit", $_POST)) { //pokud dostane data, připraví dotaz a naplní proměnnou
        $query = $db->prepare("INSERT INTO data_z_ares SET ico=?, firma=?, adresa=?, mesto=?, psc=?, dic=?, datum=?, cas=?");
        $query->execute([$_POST["fakturacni_ico"], $_POST["fakturacni_firma"], $_POST["fakturacni_adresa"], $_POST["fakturacni_mesto"], $_POST["fakturacni_psc"], $_POST["fakturacni_dic"], $datum, $cas]);
      };

      #echo "<a href=\"firmy.php\">Firmy</a>"; //tlačítko pro vykonání příkazu v firmy.php 
      echo '<form action="firmy.php" method="post">
      <input type="submit" name="zobrazeni-submit" value="Zobrazit firmy"> 
      </form>';
      

    ?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
  </body>
</html>