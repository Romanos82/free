<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nalezené firmy</title>
</head>
<body>
    <h1></h1>

    <?php

//use function PHPSTORM_META\type;

$db = new PDO(
    "mysql:host=localhost;dbname=id17042811_data_ares;charset=utf8",
    "id17042811_roman",
    "jd%{1~]Y<W&/(9GE",
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );


        $query = $db->prepare("SELECT * FROM data_z_ares ORDER BY firma ASC"); #SELECT * FROM data_z_ares ORDER BY firma DESC
        $query->execute();
        $poleFirem = $query->fetchAll();

        //var_dump($poleFirem);

        echo "<table border=1px solid>";
        echo "<tr><td>Název</td><td>IČ</td></tr>";
        foreach ($poleFirem as $Firma) {
          echo "<tr><td>{$Firma['firma']}</td><td>{$Firma['ico']}</td></tr>";
        }
        echo "</table>";
    